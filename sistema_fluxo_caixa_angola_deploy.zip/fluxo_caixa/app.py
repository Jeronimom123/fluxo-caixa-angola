from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from datetime import datetime, date
import os
import sys

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from models import (
    inicializar_bd, criar_sessao, Empresa, Conta, Categoria, Movimento, obter_saldo_conta
)

app = Flask(__name__, 
           template_folder='src/static/templates',
           static_folder='src/static')
app.secret_key = 'fluxo_caixa_secret_key_2024'

# Inicializar a base de dados
inicializar_bd()

@app.route('/')
def index():
    """Página principal do sistema"""
    session = criar_sessao()
    try:
        # Verificar se existe empresa configurada
        empresa = session.query(Empresa).first()
        if not empresa:
            return redirect(url_for('configurar_empresa'))
        
        # Obter resumo das contas
        contas = session.query(Conta).filter_by(ativa=1).all()
        resumo_contas = []
        
        for conta in contas:
            saldo_atual = obter_saldo_conta(conta.id)
            resumo_contas.append({
                'id': conta.id,
                'nome': conta.nome,
                'tipo': conta.tipo,
                'saldo_inicial': conta.saldo_inicial,
                'saldo_atual': saldo_atual
            })
        
        # Obter movimentos recentes (últimos 10)
        movimentos_recentes = session.query(Movimento).order_by(Movimento.data.desc(), Movimento.id.desc()).limit(10).all()
        
        return render_template('index.html', 
                             empresa=empresa,
                             contas=resumo_contas,
                             movimentos=movimentos_recentes)
    finally:
        session.close()

@app.route('/configurar_empresa', methods=['GET', 'POST'])
def configurar_empresa():
    """Configuração inicial da empresa"""
    if request.method == 'POST':
        nome = request.form.get('nome')
        nif = request.form.get('nif')
        
        if not nome or not nif:
            flash('Nome e NIF são obrigatórios!', 'error')
            return render_template('configurar_empresa.html')
        
        session = criar_sessao()
        try:
            # Verificar se já existe empresa
            empresa_existente = session.query(Empresa).first()
            if empresa_existente:
                flash('Empresa já configurada!', 'warning')
                return redirect(url_for('index'))
            
            # Criar nova empresa
            nova_empresa = Empresa(nome=nome, nif=nif)
            session.add(nova_empresa)
            session.commit()
            
            flash('Empresa configurada com sucesso!', 'success')
            return redirect(url_for('index'))
        finally:
            session.close()
    
    return render_template('configurar_empresa.html')

@app.route('/contas')
def listar_contas():
    """Lista todas as contas"""
    session = criar_sessao()
    try:
        contas = session.query(Conta).filter_by(ativa=1).all()
        contas_com_saldo = []
        
        for conta in contas:
            saldo_atual = obter_saldo_conta(conta.id)
            contas_com_saldo.append({
                'id': conta.id,
                'nome': conta.nome,
                'tipo': conta.tipo,
                'saldo_inicial': conta.saldo_inicial,
                'saldo_atual': saldo_atual
            })
        
        return render_template('contas.html', contas=contas_com_saldo)
    finally:
        session.close()

@app.route('/contas/nova', methods=['GET', 'POST'])
def nova_conta():
    """Criar nova conta"""
    if request.method == 'POST':
        nome = request.form.get('nome')
        tipo = request.form.get('tipo')
        saldo_inicial = float(request.form.get('saldo_inicial', 0))
        
        session = criar_sessao()
        try:
            nova_conta = Conta(nome=nome, tipo=tipo, saldo_inicial=saldo_inicial)
            session.add(nova_conta)
            session.commit()
            
            flash('Conta criada com sucesso!', 'success')
            return redirect(url_for('listar_contas'))
        finally:
            session.close()
    
    return render_template('nova_conta.html')

@app.route('/movimentos')
def listar_movimentos():
    """Lista todos os movimentos"""
    session = criar_sessao()
    try:
        movimentos = session.query(Movimento).order_by(Movimento.data.desc(), Movimento.id.desc()).all()
        return render_template('movimentos.html', movimentos=movimentos)
    finally:
        session.close()

@app.route('/movimentos/novo', methods=['GET', 'POST'])
def novo_movimento():
    """Criar novo movimento"""
    session = criar_sessao()
    try:
        if request.method == 'POST':
            # Dados básicos do movimento
            data_str = request.form.get('data')
            descricao = request.form.get('descricao')
            tipo = request.form.get('tipo')
            valor = float(request.form.get('valor'))
            conta_id = int(request.form.get('conta_id'))
            categoria_id = request.form.get('categoria_id')
            
            # Novos campos de documento
            numero_documento = request.form.get('numero_documento', '').strip()
            tipo_documento = request.form.get('tipo_documento', '').strip()
            
            # Novos campos de fornecedor
            tipo_fornecedor = request.form.get('tipo_fornecedor', '').strip()
            nome_fornecedor = request.form.get('nome_fornecedor', '').strip()
            nif_fornecedor = request.form.get('nif_fornecedor', '').strip()
            
            # Validações específicas
            if not tipo_fornecedor:
                flash('Tipo de fornecedor/cliente é obrigatório.', 'error')
                raise ValueError('Tipo de fornecedor obrigatório')
            
            if not nome_fornecedor:
                flash('Nome do fornecedor/cliente é obrigatório.', 'error')
                raise ValueError('Nome do fornecedor obrigatório')
            
            if tipo_fornecedor == 'Formal' and not nif_fornecedor:
                flash('NIF é obrigatório para fornecedores formais.', 'error')
                raise ValueError('NIF obrigatório para fornecedor formal')
            
            # Converter string de data para objeto date
            data_movimento = datetime.strptime(data_str, '%Y-%m-%d').date()
            
            # Criar movimento
            novo_mov = Movimento(
                data=data_movimento,
                descricao=descricao,
                tipo=tipo,
                valor=valor,
                conta_id=conta_id,
                categoria_id=int(categoria_id) if categoria_id else None,
                numero_documento=numero_documento if numero_documento else None,
                tipo_documento=tipo_documento if tipo_documento else None,
                tipo_fornecedor=tipo_fornecedor,
                nome_fornecedor=nome_fornecedor,
                nif_fornecedor=nif_fornecedor if nif_fornecedor else None
            )
            
            session.add(novo_mov)
            session.commit()
            
            flash('Movimento registado com sucesso!', 'success')
            return redirect(url_for('listar_movimentos'))
        
        # GET - mostrar formulário
        contas = session.query(Conta).filter_by(ativa=1).all()
        categorias = session.query(Categoria).filter_by(ativa=1).all()
        
        return render_template('novo_movimento.html', 
                             contas=contas, 
                             categorias=categorias,
                             data_hoje=date.today().strftime('%Y-%m-%d'))
    finally:
        session.close()

@app.route('/relatorios')
def relatorios():
    """Página de relatórios"""
    return render_template('relatorios.html')

@app.route('/api/relatorio_mensal')
def relatorio_mensal():
    """API para gerar relatório mensal"""
    mes = request.args.get('mes', datetime.now().month)
    ano = request.args.get('ano', datetime.now().year)
    
    session = criar_sessao()
    try:
        # Filtrar movimentos do mês
        movimentos = session.query(Movimento).filter(
            Movimento.data >= date(int(ano), int(mes), 1)
        ).filter(
            Movimento.data < date(int(ano), int(mes) + 1, 1) if int(mes) < 12 
            else date(int(ano) + 1, 1, 1)
        ).all()
        
        # Agrupar por categoria
        entradas_total = 0
        saidas_por_categoria = {}
        saidas_total = 0
        
        for movimento in movimentos:
            if movimento.tipo == 'Entrada':
                entradas_total += movimento.valor
            else:
                categoria_nome = movimento.categoria.nome if movimento.categoria else 'Sem Categoria'
                if categoria_nome not in saidas_por_categoria:
                    saidas_por_categoria[categoria_nome] = 0
                saidas_por_categoria[categoria_nome] += movimento.valor
                saidas_total += movimento.valor
        
        # Saldos das contas
        contas = session.query(Conta).filter_by(ativa=1).all()
        saldos_contas = []
        
        for conta in contas:
            saldo_atual = obter_saldo_conta(conta.id)
            saldos_contas.append({
                'nome': conta.nome,
                'tipo': conta.tipo,
                'saldo': saldo_atual
            })
        
        resultado = {
            'mes': mes,
            'ano': ano,
            'entradas_total': entradas_total,
            'saidas_total': saidas_total,
            'saldo_liquido': entradas_total - saidas_total,
            'saidas_por_categoria': saidas_por_categoria,
            'saldos_contas': saldos_contas
        }
        
        return jsonify(resultado)
    finally:
        session.close()

if __name__ == '__main__':
    import os
    
    # Configuração para produção ou desenvolvimento
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    if debug:
        print("Sistema de Fluxo de Caixa iniciado!")
        print(f"Aceda a: http://localhost:{port}")
    
    app.run(debug=debug, host='0.0.0.0', port=port)
