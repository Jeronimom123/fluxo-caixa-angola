#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de correção e verificação do Sistema de Fluxo de Caixa
Este script resolve problemas comuns e garante que o sistema funcione corretamente
"""

import os
import sys
import sqlite3
from pathlib import Path

def verificar_estrutura_diretorios():
    """Verifica e cria a estrutura de diretórios necessária"""
    print("🔍 Verificando estrutura de diretórios...")
    
    diretorios = [
        'database',
        'src',
        'src/models',
        'src/routes', 
        'src/static',
        'src/static/css',
        'src/static/js',
        'src/static/templates',
        'backups'
    ]
    
    for diretorio in diretorios:
        if not os.path.exists(diretorio):
            os.makedirs(diretorio, exist_ok=True)
            print(f"✅ Criado diretório: {diretorio}")
        else:
            print(f"✅ Diretório existe: {diretorio}")

def verificar_base_dados():
    """Verifica e corrige problemas na base de dados"""
    print("\n🗄️ Verificando base de dados...")
    
    db_path = os.path.join('database', 'fluxo_caixa.db')
    
    try:
        # Tentar conectar à base de dados
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Verificar se as tabelas existem
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tabelas = [row[0] for row in cursor.fetchall()]
        
        tabelas_esperadas = ['empresas', 'contas', 'categorias', 'movimentos']
        
        for tabela in tabelas_esperadas:
            if tabela in tabelas:
                print(f"✅ Tabela existe: {tabela}")
            else:
                print(f"❌ Tabela em falta: {tabela}")
        
        conn.close()
        
        if len(tabelas) < len(tabelas_esperadas):
            print("🔧 Reinicializando base de dados...")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Erro na base de dados: {e}")
        return False

def corrigir_imports():
    """Corrige problemas de importação"""
    print("\n🔧 Verificando imports...")
    
    # Adicionar __init__.py em falta
    init_files = [
        'src/__init__.py',
        'src/models/__init__.py',
        'src/routes/__init__.py'
    ]
    
    for init_file in init_files:
        if not os.path.exists(init_file):
            with open(init_file, 'w', encoding='utf-8') as f:
                f.write('# -*- coding: utf-8 -*-\n')
            print(f"✅ Criado: {init_file}")
        else:
            print(f"✅ Existe: {init_file}")

def verificar_ficheiros_essenciais():
    """Verifica se todos os ficheiros essenciais existem"""
    print("\n📁 Verificando ficheiros essenciais...")
    
    ficheiros_essenciais = [
        'app.py',
        'src/models/__init__.py',
        'src/static/css/style.css',
        'src/static/js/app.js',
        'src/static/templates/base.html',
        'src/static/templates/index.html',
        'requirements.txt'
    ]
    
    ficheiros_em_falta = []
    
    for ficheiro in ficheiros_essenciais:
        if os.path.exists(ficheiro):
            print(f"✅ Existe: {ficheiro}")
        else:
            print(f"❌ Em falta: {ficheiro}")
            ficheiros_em_falta.append(ficheiro)
    
    return len(ficheiros_em_falta) == 0

def testar_importacoes():
    """Testa se as importações funcionam"""
    print("\n🧪 Testando importações...")
    
    try:
        # Adicionar src ao path
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
        
        # Testar importação dos modelos
        from models import inicializar_bd, criar_sessao, Empresa, Conta, Categoria, Movimento
        print("✅ Importação dos modelos: OK")
        
        # Testar inicialização da BD
        inicializar_bd()
        print("✅ Inicialização da BD: OK")
        
        # Testar criação de sessão
        session = criar_sessao()
        session.close()
        print("✅ Criação de sessão: OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro nas importações: {e}")
        return False

def corrigir_permissoes():
    """Corrige permissões de ficheiros (principalmente para Linux/Mac)"""
    print("\n🔐 Verificando permissões...")
    
    if os.name != 'nt':  # Não é Windows
        try:
            # Dar permissões de execução aos scripts
            scripts = ['instalar.bat', 'corrigir_sistema.py']
            for script in scripts:
                if os.path.exists(script):
                    os.chmod(script, 0o755)
                    print(f"✅ Permissões corrigidas: {script}")
        except Exception as e:
            print(f"⚠️ Aviso: Não foi possível corrigir permissões: {e}")
    else:
        print("✅ Sistema Windows - permissões OK")

def main():
    """Função principal de correção"""
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║        SISTEMA DE FLUXO DE CAIXA ANGOLA - CORREÇÃO          ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()
    
    # Mudar para o diretório do script
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Executar verificações e correções
    verificar_estrutura_diretorios()
    corrigir_imports()
    corrigir_permissoes()
    
    # Verificar ficheiros
    ficheiros_ok = verificar_ficheiros_essenciais()
    
    # Verificar base de dados
    bd_ok = verificar_base_dados()
    
    # Testar importações
    imports_ok = testar_importacoes()
    
    print("\n" + "="*60)
    print("                    RESUMO DA CORREÇÃO")
    print("="*60)
    
    if ficheiros_ok and bd_ok and imports_ok:
        print("✅ SISTEMA CORRIGIDO COM SUCESSO!")
        print("\nO sistema está pronto para uso.")
        print("Execute 'python app.py' para iniciar o servidor.")
    else:
        print("❌ ALGUNS PROBLEMAS FORAM ENCONTRADOS:")
        if not ficheiros_ok:
            print("  • Ficheiros essenciais em falta")
        if not bd_ok:
            print("  • Problemas na base de dados")
        if not imports_ok:
            print("  • Problemas nas importações")
        
        print("\nPor favor, verifique os erros acima e tente novamente.")
    
    print("\n" + "="*60)

if __name__ == "__main__":
    main()
