// Funcionalidades principais do sistema de fluxo de caixa

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar componentes
    initNavigation();
    initForms();
    initTables();
    initAlerts();
    
    // Adicionar animações
    addFadeInAnimation();
});

// Navegação responsiva
function initNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
        
        // Fechar menu ao clicar em link (mobile)
        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('active');
            });
        });
    }
    
    // Marcar página ativa
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
}

// Melhorias nos formulários
function initForms() {
    // Validação em tempo real
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
        
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    });
    
    // Formatação automática de valores monetários
    const moneyInputs = document.querySelectorAll('input[type="number"][step="0.01"]');
    moneyInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value) {
                this.value = parseFloat(this.value).toFixed(2);
            }
        });
    });
    
    // Data padrão para hoje
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.value = new Date().toISOString().split('T')[0];
        }
    });
}

// Validação de campos
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    let isValid = true;
    let errorMessage = '';
    
    // Validações específicas
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'Este campo é obrigatório.';
    } else if (fieldName === 'nif' && value && (value.length < 8 || value.length > 15 || !/^[0-9]+$/.test(value))) {
        isValid = false;
        errorMessage = 'NIF deve ter entre 8 e 15 dígitos numéricos.';
    } else if (field.type === 'number' && value && isNaN(value)) {
        isValid = false;
        errorMessage = 'Deve ser um número válido.';
    } else if (field.type === 'number' && fieldName === 'valor' && parseFloat(value) <= 0) {
        isValid = false;
        errorMessage = 'O valor deve ser maior que zero.';
    }
    
    if (!isValid) {
        showFieldError(field, errorMessage);
    } else {
        clearFieldError(field);
    }
    
    return isValid;
}

// Validação de formulário completo
function validateForm(form) {
    const fields = form.querySelectorAll('input, select, textarea');
    let isValid = true;
    
    fields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

// Mostrar erro no campo
function showFieldError(field, message) {
    clearFieldError(field);
    
    field.classList.add('error');
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#dc3545';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.25rem';
    
    field.parentNode.appendChild(errorDiv);
}

// Limpar erro do campo
function clearFieldError(field) {
    field.classList.remove('error');
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

// Validação simples de NIF - aceita 8 a 15 dígitos
function validateNIF(nif) {
    return /^[0-9]{8,15}$/.test(nif);
}

// Melhorias nas tabelas
function initTables() {
    const tables = document.querySelectorAll('table');
    
    tables.forEach(table => {
        // Adicionar ordenação nas colunas
        const headers = table.querySelectorAll('th');
        headers.forEach((header, index) => {
            if (header.textContent.trim() && !header.classList.contains('no-sort')) {
                header.style.cursor = 'pointer';
                header.addEventListener('click', function() {
                    sortTable(table, index);
                });
            }
        });
        
        // Adicionar hover nas linhas
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f8f9fa';
            });
            
            row.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    });
}

// Ordenação de tabelas
function sortTable(table, columnIndex) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    const isNumeric = rows.every(row => {
        const cell = row.cells[columnIndex];
        const text = cell.textContent.trim().replace(/[€\s]/g, '');
        return !isNaN(text) && text !== '';
    });
    
    rows.sort((a, b) => {
        const aText = a.cells[columnIndex].textContent.trim();
        const bText = b.cells[columnIndex].textContent.trim();
        
        if (isNumeric) {
            const aNum = parseFloat(aText.replace(/[€\s]/g, ''));
            const bNum = parseFloat(bText.replace(/[€\s]/g, ''));
            return aNum - bNum;
        } else {
            return aText.localeCompare(bText);
        }
    });
    
    // Reordenar as linhas na tabela
    rows.forEach(row => tbody.appendChild(row));
}

// Gestão de alertas
function initAlerts() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        // Auto-fechar alertas após 5 segundos
        setTimeout(() => {
            fadeOut(alert);
        }, 5000);
        
        // Adicionar botão de fechar
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '×';
        closeBtn.style.cssText = `
            float: right;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            margin-left: 1rem;
        `;
        
        closeBtn.addEventListener('click', function() {
            fadeOut(alert);
        });
        
        alert.appendChild(closeBtn);
    });
}

// Animação de fade out
function fadeOut(element) {
    element.style.transition = 'opacity 0.5s ease';
    element.style.opacity = '0';
    
    setTimeout(() => {
        element.remove();
    }, 500);
}

// Adicionar animações de entrada
function addFadeInAnimation() {
    const elements = document.querySelectorAll('.card, .alert, table');
    
    elements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(() => {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// Formatação de valores monetários para Angola (Kwanza)
function formatMoney(value) {
    return new Intl.NumberFormat('pt-AO', {
        style: 'currency',
        currency: 'AOA',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(value);
}

// Formatação de datas para Angola
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-AO');
}

// Função para carregar relatórios via AJAX
function loadRelatorio(mes, ano) {
    const url = `/api/relatorio_mensal?mes=${mes}&ano=${ano}`;
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            displayRelatorio(data);
        })
        .catch(error => {
            console.error('Erro ao carregar relatório:', error);
            showAlert('Erro ao carregar relatório', 'error');
        });
}

// Exibir relatório na página
function displayRelatorio(data) {
    const container = document.getElementById('relatorio-container');
    if (!container) return;
    
    const html = `
        <div class="card">
            <h2>Relatório Mensal - ${data.mes}/${data.ano}</h2>
            
            <div class="resumo-financeiro">
                <div class="resumo-item positivo">
                    <h3>Total de Entradas</h3>
                    <div class="valor">${formatMoney(data.entradas_total)}</div>
                </div>
                <div class="resumo-item negativo">
                    <h3>Total de Saídas</h3>
                    <div class="valor">${formatMoney(data.saidas_total)}</div>
                </div>
                <div class="resumo-item ${data.saldo_liquido >= 0 ? 'positivo' : 'negativo'}">
                    <h3>Saldo Líquido</h3>
                    <div class="valor">${formatMoney(data.saldo_liquido)}</div>
                </div>
            </div>
            
            <h3>Saídas por Categoria</h3>
            <table>
                <thead>
                    <tr>
                        <th>Categoria</th>
                        <th>Valor</th>
                    </tr>
                </thead>
                <tbody>
                    ${Object.entries(data.saidas_por_categoria).map(([categoria, valor]) => `
                        <tr>
                            <td>${categoria}</td>
                            <td>${formatMoney(valor)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            
            <h3>Saldos das Contas</h3>
            <table>
                <thead>
                    <tr>
                        <th>Conta</th>
                        <th>Tipo</th>
                        <th>Saldo Atual</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.saldos_contas.map(conta => `
                        <tr>
                            <td>${conta.nome}</td>
                            <td>${conta.tipo}</td>
                            <td>${formatMoney(conta.saldo)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
    addFadeInAnimation();
}

// Mostrar alerta dinâmico
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    initAlerts();
}

// Confirmar ações destrutivas
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Exportar funções globais
window.FluxoCaixa = {
    loadRelatorio,
    formatMoney,
    formatDate,
    showAlert,
    confirmAction
};
