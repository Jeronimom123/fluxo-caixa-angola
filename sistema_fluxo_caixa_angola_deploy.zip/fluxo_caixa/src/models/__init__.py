from sqlalchemy import create_engine, Column, Integer, String, Float, Date, ForeignKey, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

Base = declarative_base()

class Empresa(Base):
    __tablename__ = 'empresas'
    
    id = Column(Integer, primary_key=True)
    nome = Column(String(200), nullable=False)
    nif = Column(String(20), nullable=False, unique=True)
    data_criacao = Column(DateTime, default=datetime.utcnow)

class Conta(Base):
    __tablename__ = 'contas'
    
    id = Column(Integer, primary_key=True)
    nome = Column(String(100), nullable=False)
    tipo = Column(String(20), nullable=False)  # 'Caixa' ou 'Banco'
    saldo_inicial = Column(Float, nullable=False, default=0.0)
    ativa = Column(Integer, default=1)  # 1 = ativa, 0 = inativa
    data_criacao = Column(DateTime, default=datetime.utcnow)
    
    # Relacionamento com movimentos
    movimentos = relationship("Movimento", back_populates="conta")

class Categoria(Base):
    __tablename__ = 'categorias'
    
    id = Column(Integer, primary_key=True)
    nome = Column(String(100), nullable=False)
    descricao = Column(String(255))
    ativa = Column(Integer, default=1)  # 1 = ativa, 0 = inativa
    
    # Relacionamento com movimentos
    movimentos = relationship("Movimento", back_populates="categoria")

class Movimento(Base):
    __tablename__ = 'movimentos'
    
    id = Column(Integer, primary_key=True)
    data = Column(Date, nullable=False)
    tipo = Column(String(10), nullable=False)  # 'Entrada' ou 'Saida'
    descricao = Column(String(500), nullable=False)
    valor = Column(Float, nullable=False)
    conta_id = Column(Integer, ForeignKey('contas.id'), nullable=False)
    categoria_id = Column(Integer, ForeignKey('categorias.id'), nullable=True)
    
    # Informações de documento
    numero_documento = Column(String(50), nullable=True)
    tipo_documento = Column(String(50), nullable=True)  # 'Fatura', 'Recibo', 'Nota de Débito', etc.
    
    # Informações de fornecedor/cliente
    tipo_fornecedor = Column(String(20), nullable=True)  # 'Formal' ou 'Informal'
    nome_fornecedor = Column(String(200), nullable=True)
    nif_fornecedor = Column(String(20), nullable=True)
    
    data_criacao = Column(DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    conta = relationship("Conta", back_populates="movimentos")
    categoria = relationship("Categoria", back_populates="movimentos")

# Configuração da base de dados
def criar_engine():
    """Cria o engine da base de dados SQLite"""
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'database', 'fluxo_caixa.db')
    
    # Garantir que o diretório existe
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    engine = create_engine(f'sqlite:///{db_path}', echo=False)
    return engine

def criar_sessao():
    """Cria uma sessão da base de dados"""
    engine = criar_engine()
    Session = sessionmaker(bind=engine)
    return Session()

def inicializar_bd():
    """Inicializa a base de dados criando todas as tabelas"""
    engine = criar_engine()
    Base.metadata.create_all(engine)
    
    # Criar categorias padrão se não existirem
    session = criar_sessao()
    try:
        if session.query(Categoria).count() == 0:
            categorias_padrao = [
                Categoria(nome="Rendas", descricao="Pagamento de rendas e alugueres"),
                Categoria(nome="Condomínios", descricao="Taxas de condomínio e manutenção predial"),
                Categoria(nome="Água", descricao="Conta de água - EPAL Angola"),
                Categoria(nome="Luz", descricao="Conta de eletricidade - ENE Angola"),
                Categoria(nome="Combustível", descricao="Gasóleo, gasolina e gás doméstico"),
                Categoria(nome="Produtos de Limpeza", descricao="Detergentes e material de limpeza"),
                Categoria(nome="Manutenção", descricao="Manutenção de equipamentos e instalações"),
                Categoria(nome="Alimentação", descricao="Cafés, chás, águas e alimentação"),
                Categoria(nome="Material de Escritório", descricao="Papel, canetas, tinteiros e consumíveis"),
                Categoria(nome="Seguros", descricao="Seguros diversos"),
                Categoria(nome="Telecomunicações", descricao="Internet, telefone e comunicações"),
                Categoria(nome="Transporte", descricao="Combustível, manutenção de viaturas e transportes"),
                Categoria(nome="Impostos e Taxas", descricao="Impostos, taxas e contribuições"),
                Categoria(nome="Avenças com Contabilistas", descricao="Honorários e avenças de contabilistas e consultores fiscais"),
                Categoria(nome="Outras Avenças", descricao="Avenças com advogados, consultores, auditores e outros profissionais"),
                Categoria(nome="Outras Despesas", descricao="Despesas diversas não categorizadas")
            ]
            
            for categoria in categorias_padrao:
                session.add(categoria)
            
            session.commit()
    finally:
        session.close()

def obter_saldo_conta(conta_id):
    """Calcula o saldo atual de uma conta baseado nos movimentos"""
    session = criar_sessao()
    try:
        # Obter todos os movimentos da conta
        query = session.query(Movimento).filter_by(conta_id=conta_id)
        movimentos = query.all()
        
        # Calcular saldo inicial
        conta = session.query(Conta).get(conta_id)
        if not conta:
            return 0.0
        
        saldo = conta.saldo_inicial
        
        # Aplicar movimentos
        for movimento in movimentos:
            if movimento.tipo == 'Entrada':
                saldo += movimento.valor
            else:  # Saida
                saldo -= movimento.valor
        
        return saldo
    finally:
        session.close()