# Guia de Hospedagem Online - Sistema de Fluxo de Caixa Angola

## 📱 Acesso Mobile e Hospedagem na Internet

Este guia explica como hospedar o sistema online para acesso via smartphone, tablet ou qualquer dispositivo com internet.

## 🌐 Opções de Hospedagem

### 1. Hospedagem Gratuita (Recomendada para Teste)

#### **Render.com** (Gratuita)
1. Criar conta em [render.com](https://render.com)
2. Conectar repositório GitHub
3. Configurar como "Web Service"
4. Comando de build: `pip install -r requirements.txt`
5. Comando de start: `python app.py`
6. URL automática: `https://seu-app.onrender.com`

#### **Railway.app** (Gratuita)
1. Criar conta em [railway.app](https://railway.app)
2. Conectar GitHub ou fazer deploy direto
3. Configuração automática do Python
4. URL automática gerada

#### **Heroku** (Gratuita com limitações)
1. Criar conta em [heroku.com](https://heroku.com)
2. Instalar Heroku CLI
3. Fazer deploy via Git
4. Configurar variáveis de ambiente

### 2. Hospedagem Paga (Recomendada para Produção)

#### **DigitalOcean** (5-10 USD/mês)
- Servidor VPS completo
- Controlo total do sistema
- Backup automático disponível

#### **AWS EC2** (5-15 USD/mês)
- Infraestrutura robusta
- Escalabilidade automática
- Integração com outros serviços

#### **Vultr** (2.50-5 USD/mês)
- Servidores rápidos
- Múltiplas localizações
- Preços competitivos

## 🚀 Deploy Rápido - Render.com (Gratuito)

### Passo 1: Preparar Ficheiros
Criar ficheiro `requirements.txt`:
```
Flask==2.3.3
SQLAlchemy==2.0.21
```

Criar ficheiro `Procfile`:
```
web: python app.py
```

### Passo 2: Configurar app.py para Produção
```python
import os

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)
```

### Passo 3: Deploy
1. Fazer upload dos ficheiros para GitHub
2. Conectar Render.com ao repositório
3. Configurar como Web Service
4. Deploy automático

## 📱 Funcionalidades Mobile

### ✅ Interface Responsiva
- **Smartphone**: Layout otimizado para telas pequenas
- **Tablet**: Interface adaptada para telas médias
- **Desktop**: Experiência completa

### ✅ PWA (Progressive Web App)
- **Instalação**: Adicionar à tela inicial como app
- **Offline**: Funciona sem internet (limitado)
- **Notificações**: Alertas importantes
- **Ícone**: Ícone personalizado na tela inicial

### ✅ Funcionalidades Touch
- **Gestos**: Navegação por gestos
- **Zoom**: Controlo de zoom otimizado
- **Teclado**: Teclado numérico para valores
- **Formulários**: Campos otimizados para mobile

## 🔧 Configuração para Acesso Remoto

### Opção 1: Rede Local (WiFi)
```bash
# No Windows, executar:
python app.py

# Aceder via smartphone na mesma rede:
# http://IP_DO_PC:5000
# Exemplo: http://192.168.1.100:5000
```

### Opção 2: Túnel Público (ngrok)
```bash
# Instalar ngrok
# Executar o sistema
python app.py

# Em outro terminal
ngrok http 5000

# URL pública gerada: https://abc123.ngrok.io
```

### Opção 3: Hospedagem Online
- URL permanente: `https://seu-dominio.com`
- Acesso de qualquer lugar do mundo
- SSL automático (HTTPS)

## 📊 Vantagens do Acesso Mobile

### 🏢 Para o Escritório
- **Visibilidade**: Chefe pode ver relatórios em tempo real
- **Aprovação**: Aprovar despesas remotamente
- **Monitorização**: Acompanhar fluxo de caixa em viagem

### 👥 Para a Equipa
- **Mobilidade**: Registar movimentos fora do escritório
- **Rapidez**: Entrada de dados mais rápida no mobile
- **Sincronização**: Dados sempre atualizados

### 💼 Para o Negócio
- **Produtividade**: Gestão financeira em qualquer lugar
- **Controlo**: Supervisão constante das finanças
- **Relatórios**: Acesso instantâneo a relatórios

## 🔒 Segurança

### Recomendações
1. **HTTPS**: Sempre usar conexão segura
2. **Passwords**: Implementar autenticação
3. **Backup**: Backup automático da base de dados
4. **Firewall**: Configurar firewall adequado

### Para Produção
```python
# Adicionar ao app.py
from werkzeug.security import generate_password_hash, check_password_hash

# Implementar login/logout
# Configurar sessões seguras
# Adicionar validação de acesso
```

## 📋 Checklist de Deploy

### ✅ Antes do Deploy
- [ ] Testar sistema localmente
- [ ] Configurar requirements.txt
- [ ] Preparar base de dados
- [ ] Configurar variáveis de ambiente
- [ ] Testar responsividade mobile

### ✅ Após Deploy
- [ ] Testar URL pública
- [ ] Verificar funcionalidades mobile
- [ ] Configurar domínio personalizado
- [ ] Implementar backup automático
- [ ] Testar PWA (adicionar à tela inicial)

## 🆘 Suporte e Troubleshooting

### Problemas Comuns
1. **Erro 500**: Verificar logs do servidor
2. **Base de dados**: Verificar permissões
3. **CSS não carrega**: Verificar paths estáticos
4. **Mobile não funciona**: Verificar viewport meta tag

### Logs e Debug
```bash
# Ver logs no Render.com
# Dashboard > Logs

# Debug local
export FLASK_DEBUG=1
python app.py
```

## 🌟 Próximos Passos

1. **Deploy inicial** em plataforma gratuita
2. **Testar acesso mobile** em diferentes dispositivos
3. **Configurar domínio** personalizado
4. **Implementar autenticação** para segurança
5. **Configurar backup** automático
6. **Monitorizar performance** e uso

---

**💡 Dica**: Comece com Render.com (gratuito) para testar, depois migre para hospedagem paga quando o sistema estiver em uso regular.
