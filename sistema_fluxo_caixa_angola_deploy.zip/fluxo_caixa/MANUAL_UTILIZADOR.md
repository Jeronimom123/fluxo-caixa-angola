# Manual do Utilizador - Sistema de Fluxo de Caixa

## Índice

1. [Introdução](#introdução)
2. [Instalação](#instalação)
3. [Configuração Inicial](#configuração-inicial)
4. [Funcionalidades Principais](#funcionalidades-principais)
5. [Gestão de Contas](#gestão-de-contas)
6. [Registo de Movimentos](#registo-de-movimentos)
7. [Relatórios](#relatórios)
8. [Backup e Manutenção](#backup-e-manutenção)
9. [Resolução de Problemas](#resolução-de-problemas)
10. [Suporte Técnico](#suporte-técnico)

---

## Introdução

O **Sistema de Fluxo de Caixa** é uma aplicação web desenvolvida especificamente para facilitar a gestão financeira diária de pequenas e médias empresas. O sistema foi concebido para ser simples de usar, mesmo para utilizadores com poucos conhecimentos de contabilidade.

### Características Principais

- **Interface Web Simples**: Acesso através de qualquer navegador
- **Multi-empresa**: Suporte para diferentes empresas numa única instalação
- **Gestão de Contas**: Controlo de caixas e contas bancárias
- **Categorização**: Organização automática de despesas por categorias
- **Relatórios Profissionais**: Relatórios mensais prontos para aprovação
- **Backup Automático**: Sistema de backup integrado
- **Instalação Simples**: Instalador automático para Windows

---

## Instalação

### Requisitos do Sistema

- **Sistema Operativo**: Windows 7 ou superior
- **Python**: Versão 3.7 ou superior
- **Navegador Web**: Chrome, Firefox, Edge ou Safari
- **Espaço em Disco**: Mínimo 100 MB

### Processo de Instalação

1. **Descarregar o Sistema**
   - Extrair todos os ficheiros para uma pasta (ex: `C:\FluxoCaixa`)

2. **Executar o Instalador**
   - Fazer duplo clique no ficheiro `instalar.bat`
   - Seguir as instruções no ecrã

3. **Configurar a Empresa**
   - Inserir o nome da empresa
   - Inserir o NIF (9 dígitos)

4. **Aguardar a Instalação**
   - O sistema instalará automaticamente todas as dependências
   - Criará a base de dados
   - Configurará os ficheiros necessários

### Ficheiros Criados Durante a Instalação

| Ficheiro | Descrição |
|----------|-----------|
| `iniciar_sistema.bat` | Script para iniciar o sistema |
| `criar_backup.bat` | Script para criar backups |
| `config_empresa.txt` | Configuração da empresa |
| `README.md` | Documentação básica |
| `database/fluxo_caixa.db` | Base de dados SQLite |

---

## Configuração Inicial

### Primeiro Acesso

1. **Iniciar o Sistema**
   - Executar `iniciar_sistema.bat`
   - Aguardar a mensagem "Sistema iniciado"

2. **Aceder à Interface Web**
   - Abrir o navegador
   - Navegar para `http://localhost:5000`

3. **Configurar Contas Iniciais**
   - Criar pelo menos uma conta (caixa ou banco)
   - Definir o saldo inicial de cada conta

### Configuração de Categorias

O sistema vem com categorias pré-definidas:

- **Rendas**: Pagamento de rendas
- **Condomínios**: Taxas de condomínio
- **Água**: Conta de água
- **Luz**: Conta de eletricidade
- **Gás**: Conta de gás
- **Detergentes**: Produtos de limpeza
- **Manutenção AC**: Manutenção de ar condicionado
- **Cafés**: Despesas com café
- **Chás**: Despesas com chá
- **Águas**: Água para beber
- **Material Escritório**: Papel, colas, lapiseiras, tinteiros
- **Seguros**: Pagamentos de seguros
- **Outras Despesas**: Despesas diversas

---

## Funcionalidades Principais

### Dashboard

O dashboard apresenta uma visão geral do estado financeiro:

- **Resumo das Contas**: Saldos atuais de todas as contas
- **Movimentos Recentes**: Últimas transações registadas
- **Estatísticas Rápidas**: Totais e contadores
- **Ações Rápidas**: Acesso direto às funcionalidades principais

### Navegação

A navegação é feita através do menu principal:

- **Dashboard**: Página inicial com resumo
- **Contas**: Gestão de caixas e bancos
- **Movimentos**: Histórico de transações
- **Novo Movimento**: Registo de entradas e saídas
- **Relatórios**: Geração de relatórios mensais

---

## Gestão de Contas

### Tipos de Contas

**Caixas**
- Dinheiro físico em espécie
- Exemplos: "Caixa Principal", "Fundo de Maneio"

**Bancos**
- Contas bancárias e depósitos
- Exemplos: "Millennium Conta Corrente", "CGD Poupança"

### Criar Nova Conta

1. Aceder ao menu **Contas**
2. Clicar em **Nova Conta**
3. Preencher os campos:
   - **Nome**: Nome descritivo da conta
   - **Tipo**: Caixa ou Banco
   - **Saldo Inicial**: Valor atual da conta
4. Clicar em **Criar Conta**

### Visualizar Contas

A página de contas apresenta:

- **Resumo Geral**: Totais por tipo de conta
- **Lista Detalhada**: Todas as contas com saldos
- **Análise por Tipo**: Separação entre caixas e bancos

---

## Registo de Movimentos

### Tipos de Movimentos

**Entradas (Recebimentos)**
- Dinheiro que entra na conta
- Exemplos: Vendas, recebimentos de clientes

**Saídas (Pagamentos)**
- Dinheiro que sai da conta
- Exemplos: Pagamentos a fornecedores, despesas

### Registar Novo Movimento

1. Aceder ao menu **Novo Movimento**
2. Preencher os campos obrigatórios:
   - **Data**: Data do movimento
   - **Tipo**: Entrada ou Saída
   - **Descrição**: Descrição clara do movimento
   - **Valor**: Montante (sempre positivo)
   - **Conta**: Conta onde registar o movimento
3. Para saídas, selecionar a **Categoria**
4. Clicar em **Registar Movimento**

### Boas Práticas

- Registar movimentos no mesmo dia em que ocorrem
- Usar descrições claras e específicas
- Sempre associar saídas a uma categoria
- Verificar se selecionou a conta correta
- O valor deve ser sempre positivo (o tipo define se é entrada ou saída)

### Visualizar Movimentos

A página de movimentos oferece:

- **Resumo Financeiro**: Totais de entradas, saídas e saldo líquido
- **Filtros**: Por tipo, data ou período
- **Lista Completa**: Todos os movimentos ordenados por data
- **Ordenação**: Clique nos cabeçalhos para ordenar

---

## Relatórios

### Relatório Mensal

O relatório mensal é a funcionalidade principal para aprovação das chefias.

#### Conteúdo do Relatório

1. **Cabeçalho**
   - Nome da empresa e NIF
   - Período do relatório
   - Data de geração

2. **Resumo Executivo**
   - Total de entradas
   - Total de saídas
   - Resultado líquido

3. **Análise de Despesas por Categoria**
   - Breakdown detalhado por categoria
   - Identificação da maior despesa

4. **Posição das Contas**
   - Saldo atual de cada conta
   - Saldo total consolidado

5. **Indicadores de Performance**
   - Taxa de crescimento
   - Eficiência de gastos

6. **Seção de Aprovação**
   - Espaços para assinaturas
   - Data de aprovação

#### Gerar Relatório

1. Aceder ao menu **Relatórios**
2. Selecionar o mês e ano desejados
3. Clicar em **Gerar Relatório**
4. Para imprimir, clicar em **Imprimir**

#### Relatórios Rápidos

- **Mês Atual**: Relatório do mês em curso
- **Mês Anterior**: Relatório do mês passado
- **Últimos 3 Meses**: Comparativo (funcionalidade futura)

---

## Backup e Manutenção

### Criar Backup

1. **Automático**: Executar `criar_backup.bat`
2. **Manual**: Copiar o ficheiro `database/fluxo_caixa.db`

### Restaurar Backup

1. Parar o sistema (fechar o navegador e terminal)
2. Substituir `database/fluxo_caixa.db` pelo backup
3. Reiniciar o sistema

### Manutenção Regular

- **Backup Semanal**: Recomendado criar backup todas as semanas
- **Limpeza**: Manter apenas os últimos 10 backups
- **Verificação**: Executar `corrigir_sistema.py` mensalmente

---

## Resolução de Problemas

### Problemas Comuns

#### Sistema Não Inicia

**Sintomas**: Erro ao executar `iniciar_sistema.bat`

**Soluções**:
1. Verificar se Python está instalado: `python --version`
2. Reinstalar dependências: `pip install -r requirements.txt`
3. Executar script de correção: `python corrigir_sistema.py`

#### Página Não Carrega

**Sintomas**: Erro 404 ou página em branco

**Soluções**:
1. Verificar se o servidor está rodando
2. Tentar aceder a `http://127.0.0.1:5000`
3. Reiniciar o sistema

#### Erro na Base de Dados

**Sintomas**: Erro SQLite ou tabelas em falta

**Soluções**:
1. Executar `python corrigir_sistema.py`
2. Se persistir, apagar `database/fluxo_caixa.db` e reiniciar
3. Restaurar backup se disponível

#### CSS Não Carrega

**Sintomas**: Página sem formatação

**Soluções**:
1. Limpar cache do navegador (Ctrl+F5)
2. Verificar se ficheiros CSS existem
3. Executar script de correção

### Script de Correção Automática

O ficheiro `corrigir_sistema.py` resolve automaticamente:

- Estrutura de diretórios em falta
- Problemas de importação
- Permissões de ficheiros
- Inicialização da base de dados

**Uso**: `python corrigir_sistema.py`

---

## Suporte Técnico

### Informações do Sistema

- **Versão**: 1.0
- **Tecnologia**: Python Flask + SQLite
- **Compatibilidade**: Windows 7+, Python 3.7+

### Ficheiros de Log

Em caso de problemas, verificar:
- Terminal onde o sistema está rodando
- Mensagens de erro no navegador (F12 → Console)

### Contacto

Para suporte adicional:
1. Consultar este manual
2. Executar script de correção
3. Contactar o administrador do sistema

### Estrutura de Ficheiros

```
fluxo_caixa/
├── app.py                          # Aplicação principal
├── instalar.bat                    # Instalador Windows
├── iniciar_sistema.bat             # Script de arranque
├── criar_backup.bat                # Script de backup
├── corrigir_sistema.py             # Script de correção
├── requirements.txt                # Dependências Python
├── config_empresa.txt              # Configuração da empresa
├── README.md                       # Documentação básica
├── MANUAL_UTILIZADOR.md            # Este manual
├── database/
│   └── fluxo_caixa.db             # Base de dados SQLite
├── backups/                        # Backups automáticos
├── src/
│   ├── models/
│   │   └── __init__.py            # Modelos da base de dados
│   └── static/
│       ├── css/
│       │   └── style.css          # Estilos CSS
│       ├── js/
│       │   └── app.js             # JavaScript
│       └── templates/
│           ├── base.html          # Template base
│           ├── index.html         # Dashboard
│           ├── contas.html        # Gestão de contas
│           ├── movimentos.html    # Lista de movimentos
│           ├── novo_movimento.html # Novo movimento
│           ├── nova_conta.html    # Nova conta
│           ├── relatorios.html    # Relatórios
│           └── configurar_empresa.html # Configuração
```

---

**© 2024 Sistema de Fluxo de Caixa - Desenvolvido para facilitar a gestão financeira empresarial**
