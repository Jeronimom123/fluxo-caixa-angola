# Deploy no Render.com - Guia Passo a Passo

## 🎯 Objetivo
Hospedar o Sistema de Fluxo de Caixa Angola no Render.com para acesso via smartphone de qualquer lugar.

## 📋 Pré-requisitos
- ✅ Conta no GitHub (que já tem)
- ✅ Sistema de Fluxo de Caixa (ficheiros prontos)
- ✅ Conta no Render.com (gratuita)

## 🚀 Passo 1: Preparar Repositório GitHub

### 1.1 Criar Novo Repositório
1. Ir para [github.com](https://github.com)
2. Clicar em **"New repository"**
3. Nome: `fluxo-caixa-angola`
4. Descrição: `Sistema de Fluxo de Caixa para empresas angolanas`
5. Público ou Privado (sua escolha)
6. Clicar **"Create repository"**

### 1.2 Upload dos Ficheiros
**Opção A: Via Interface Web**
1. Clicar **"uploading an existing file"**
2. Arrastar todos os ficheiros do sistema
3. Commit message: `Sistema inicial`
4. Clicar **"Commit changes"**

**Opção B: Via Git (se tiver instalado)**
```bash
git clone https://github.com/SEU_USERNAME/fluxo-caixa-angola.git
cd fluxo-caixa-angola
# Copiar todos os ficheiros do sistema para esta pasta
git add .
git commit -m "Sistema inicial"
git push origin main
```

## 🌐 Passo 2: Criar Conta no Render.com

### 2.1 Registar
1. Ir para [render.com](https://render.com)
2. Clicar **"Get Started for Free"**
3. **"Sign up with GitHub"** (recomendado)
4. Autorizar acesso ao GitHub
5. Verificar email se necessário

### 2.2 Conectar GitHub
1. No dashboard do Render
2. Clicar **"Connect GitHub"**
3. Autorizar acesso aos repositórios
4. Selecionar repositório `fluxo-caixa-angola`

## 🔧 Passo 3: Configurar Web Service

### 3.1 Criar Novo Service
1. No dashboard do Render
2. Clicar **"New +"**
3. Selecionar **"Web Service"**
4. Escolher repositório `fluxo-caixa-angola`
5. Clicar **"Connect"**

### 3.2 Configurações Essenciais
```
Name: fluxo-caixa-angola
Environment: Python 3
Region: Frankfurt (mais próximo de Angola)
Branch: main
Root Directory: (deixar vazio)
Build Command: pip install -r requirements.txt
Start Command: python app.py
```

### 3.3 Configurações Avançadas
```
Instance Type: Free
Auto-Deploy: Yes (recomendado)
```

### 3.4 Variáveis de Ambiente
Adicionar se necessário:
```
FLASK_ENV=production
PORT=10000 (automático)
```

## 🚀 Passo 4: Deploy

### 4.1 Iniciar Deploy
1. Clicar **"Create Web Service"**
2. Aguardar processo de build (5-10 minutos)
3. Acompanhar logs em tempo real

### 4.2 Verificar Deploy
- ✅ Build successful
- ✅ Service running
- ✅ URL gerada: `https://fluxo-caixa-angola.onrender.com`

## 📱 Passo 5: Testar Acesso Mobile

### 5.1 Aceder via Smartphone
1. Abrir browser no smartphone
2. Ir para URL gerada
3. Testar funcionalidades:
   - ✅ Login/configuração empresa
   - ✅ Criar contas
   - ✅ Registar movimentos
   - ✅ Ver relatórios

### 5.2 Instalar como PWA
1. No browser do smartphone
2. Menu > **"Adicionar à tela inicial"**
3. Confirmar instalação
4. Usar como app nativo

## 🔧 Passo 6: Configurações Adicionais

### 6.1 Domínio Personalizado (Opcional)
1. No dashboard do Render
2. Settings > Custom Domains
3. Adicionar domínio próprio
4. Configurar DNS

### 6.2 SSL Automático
- ✅ HTTPS automático (incluído)
- ✅ Certificado SSL gratuito
- ✅ Renovação automática

## 🔍 Troubleshooting

### Problemas Comuns

**Build Failed**
```
Solução:
1. Verificar requirements.txt
2. Verificar sintaxe Python
3. Ver logs detalhados
```

**Service Not Starting**
```
Solução:
1. Verificar Start Command
2. Verificar porta (usar PORT env var)
3. Ver logs de runtime
```

**Database Issues**
```
Solução:
1. SQLite funciona no Render
2. Verificar permissões de escrita
3. Considerar PostgreSQL para produção
```

## 📊 Monitorização

### Logs
1. Dashboard > Service > Logs
2. Ver logs em tempo real
3. Debug problemas

### Métricas
1. CPU usage
2. Memory usage
3. Request count
4. Response time

## 💰 Custos

### Plano Gratuito
- ✅ 750 horas/mês
- ✅ SSL gratuito
- ✅ Deploy automático
- ⚠️ Sleep após 15min inatividade
- ⚠️ 512MB RAM

### Upgrade (se necessário)
- **Starter**: $7/mês
- **Standard**: $25/mês
- Sem sleep, mais recursos

## 🔒 Segurança

### Recomendações
1. **Variáveis de ambiente** para dados sensíveis
2. **HTTPS** sempre ativo
3. **Backup** regular da base de dados
4. **Monitorização** de acessos

### Implementar Autenticação
```python
# Adicionar ao app.py futuramente
from flask_login import LoginManager
# Implementar sistema de login
```

## 📋 Checklist Final

### ✅ Antes do Deploy
- [ ] Ficheiros no GitHub
- [ ] requirements.txt correto
- [ ] Procfile criado
- [ ] app.py configurado para produção

### ✅ Após Deploy
- [ ] URL funciona
- [ ] Mobile responsivo
- [ ] PWA instalável
- [ ] Todas as funcionalidades OK
- [ ] SSL ativo (HTTPS)

## 🎯 Resultado Final

Após seguir este guia terá:

1. **URL pública**: `https://fluxo-caixa-angola.onrender.com`
2. **Acesso mobile**: Funciona em qualquer smartphone
3. **PWA**: Instalável como app nativo
4. **SSL**: Conexão segura automática
5. **Deploy automático**: Atualizações automáticas do GitHub

## 📞 Suporte

Se encontrar problemas:
1. Verificar logs no Render dashboard
2. Consultar documentação: [render.com/docs](https://render.com/docs)
3. Verificar status: [status.render.com](https://status.render.com)

---

**🎉 Parabéns!** Após este processo terá o sistema funcionando online e acessível via smartphone de qualquer lugar do mundo!
